const rowsIndex = require("./rowsIndex.js");
const columnsIndex = require("./columnsIndex.js");

const checkIfvalueIsValidButAlreadyAddedToPuzzle = (
  selectedRow,
  row,
  column,
  value
) => {
  // console.log("selectedRow", selectedRow);

  // console.log("rowsIndex", rowsIndex);
  // console.log("columnsIndex", columnsIndex);
  let valueIsValidButAlreadyAddedToPuzzle;
  // check if value is in specified cordinate in selected row

  // console.log(
  //   "rowsIndex.row",
  //   rowsIndex[row],
  //   "columnsIndex.column",
  //   columnsIndex[column]
  // );
  // let valueIndex = rowsIndex[row] + columnsIndex[column] - 1; //set index of value in string is a product of row and column index minus one
  // let valueIndex = rowsIndex[row] * columnsIndex[column] - 1; //set index of value in string is a product of row and column index minus one
  // console.log("valueIndex", valueIndex);
  // console.log("selectedRow cordinate", selectedRow[column - 1]);
  for (const [rowkey, rowValue] of Object.entries(selectedRow[column - 1])) {
    // iterate selected cordinate in selectedRow
    if (rowValue === `${value}`) {
      // check if value at the selected cordiante is equal to provided value
      valueIsValidButAlreadyAddedToPuzzle = true;
    } else {
      // value at the selected cordiante is not equal to provided value
      valueIsValidButAlreadyAddedToPuzzle = false;
    }
  }
  return valueIsValidButAlreadyAddedToPuzzle;
};

module.exports = checkIfvalueIsValidButAlreadyAddedToPuzzle;
