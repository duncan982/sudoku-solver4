// const rowsIndex = {
//   A: 1,
//   B: 2,
//   C: 3,
//   D: 4,
//   E: 5,
//   F: 6,
//   G: 7,
//   H: 8,
//   I: 9
// };

const rowsIndex = {
  A: 0,
  B: 9,
  C: 18,
  D: 27,
  E: 36,
  F: 45,
  G: 54,
  H: 63,
  I: 72
};

module.exports = rowsIndex;
