const regeneratePuzzle = require("./regeneratePuzzle.js");
const updatePuzzleString = require("./updatePuzzleString.js");
const possiblePuzzelItems = require("./possiblePuzzelItems.js");
const solveCordinate = (puzzleValuesWithKeys, obtainedCoordinate) => {
  let updatedPuzzleString;
  let regeneratedPuzzle;

  let row;
  let column;

  for (const [key, value] of Object.entries(obtainedCoordinate)) {
    row = value[0];
    column = value[1];
  }
  // console.log("row in request is", row, "and column in request is", column);

  // regenerate puzzle
  regeneratedPuzzle = regeneratePuzzle(puzzleValuesWithKeys);
  // console.log("regeneratedPuzzle", regeneratedPuzzle);

  // check among the possiblePuzzelItems which ones fits the coordinate
  for (let i = 0; i < possiblePuzzelItems.length; i++) {
    let value = possiblePuzzelItems[i];

    updatedPuzzleString = updatePuzzleString(
      regeneratedPuzzle,
      row,
      column,
      value
    );
    // console.log("updatePuzzleString", updatedPuzzleString);
  }
  return updatedPuzzleString;
};

module.exports = solveCordinate;
