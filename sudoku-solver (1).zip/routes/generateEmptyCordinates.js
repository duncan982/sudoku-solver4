const generateEmptyCordinates = (selectedRow) => {
  /** generate empty cordinates from selected row */
  let emptyCordinates = []; // create a list to hold empty corrdiantes

  selectedRow.forEach((cordinate) => {
    for (const [keys, values] of Object.entries(cordinate)) {
      // iterate cordinae key value pair
      if (values === ".") {
        // check if value at the specified cordinate is empty
        // console.log('emptyCordinate is', values);
        emptyCordinates.push(cordinate);
        // console.log('emptyCordinate is', emptyCordinate)
      }
    }
  });

  return emptyCordinates;
};

module.exports = generateEmptyCordinates;
