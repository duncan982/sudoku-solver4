const checkPuzzle = require("./checkPuzzle.js");
const solveCordinate = require("./solveCordinate.js");
const generatePuzzleValuesWithKeys = require("./generatePuzzleValuesWithKeys.js");

const solvePuzzle = (puzzle, puzzleCordinatesWithKeys) => {
  let regeneratedPuzzle;
  // console.log('puzzle is', puzzle);

  if (puzzleCordinatesWithKeys.length > 0) {
    // check to see if there are still coordinates to work with

    let obtainedCoordinate = puzzleCordinatesWithKeys.splice(0, 1)[0];
    // console.log("obtainedCoordinate", obtainedCoordinate);

    // create an array of puzzle string values
    let puzzleValuesWithKeys = generatePuzzleValuesWithKeys(puzzle);
    // console.log("puzzleValuesWithKeys", puzzleValuesWithKeys);

    let solvedPuzzle = solveCordinate(puzzleValuesWithKeys, obtainedCoordinate);
    // console.log("puzzle to be solved is", solvedPuzzle);

    regeneratedPuzzle = solvedPuzzle.regeneratedPuzzle;

    // check if puzzle is solved
    let isPuzzleSolved = checkPuzzle(regeneratedPuzzle);
    // console.log('isPuzzleSolved in solvePuzzle.js', isPuzzleSolved)
    if (isPuzzleSolved.validate === false) {
      // if it is not solved work on it to solve it
      // console.log("puzzle is not solved", regeneratedPuzzle);
      return solvePuzzle(regeneratedPuzzle, puzzleCordinatesWithKeys);
    } else {
      // if it is solved return it and exit
      // console.log("puzzle is solved", regeneratedPuzzle);
      return regeneratedPuzzle;
    }
  }
};

module.exports = solvePuzzle;
